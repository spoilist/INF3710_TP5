export interface Animal {
    "numAnimal": string;
    "numProprietaire": string;
    "numClinique": string;
    "nom": string;
    "typeAnimal": string;
    "description": string;
    "dateNaissance": string;
    "dateInscription": string;
    "etatActuel": string;
}