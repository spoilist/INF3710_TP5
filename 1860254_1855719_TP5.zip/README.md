# INF3710_TP5
Manuel de l’utilisateur :
Étapes à suivre :
1.    S’assurer d’avoir Angular et Express installé sur la machine.
2.    Ouvrir un terminal à l’intérieur du dossier client et exécuter la commande npm i.
3.    Ouvrir un terminal à l’intérieur du dossier server et exécuter la commande npm i.
4.    Exécuter la commande npm start dans le terminal client.
5.    Exécuter la commande npm start dans le terminal server.
6.    Si tout s’est bien passé, une nouvelle fenêtre s’ouvrera dans votre navigateur. L’application est prête à être utilisé.
7.    Le schéma et le data se trouvent dans les fichiers bdschema.sql et data.sql.
8.    Avant de commencer, appuyez sur le bouton Nouvelle BD.
*À noter que le serveur peut à certains moments planter. Si c’est le cas, seulement relancer le serveur.
